<?php  // Inclure les infos de connexion à la bdd

$template = 'posts.phtml';   
include('layout.phtml');

?>