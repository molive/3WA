<?php // Insérer le nouveau post dans la table posts.php

// Inclure le fichier common.php pour avoir accès à la base de données et aux sessions

// 1) Stocker le post dans la table "posts"

// 2) Rediriger l'utilisateur sur la page index.php