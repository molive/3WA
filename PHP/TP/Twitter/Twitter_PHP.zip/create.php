<?php // Insérer le nouveau post dans la table posts.php

// Inclure les infos de connexion à la bdd

// 1) Stocker le post dans la table "posts"

// 2) Rediriger l'utilisateur sur la page index.php