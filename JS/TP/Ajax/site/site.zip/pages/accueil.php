	<h1>Mon super site</h1>
			
			<p>
				<img src="http://howtobelikebarneystinson.com/wp-content/uploads/2013/05/barney-stinson.jpg">
			</p>