<h1>Liste de tous les membres inscrits</h1>

Pseudo: Merlin<br>
Email: merlin@enchanteur.com
<hr>

Pseudo: Toto<br>
Email: toto@tata.com
<hr>

Pseudo: Tony<br>
Email: tony@stark.com
